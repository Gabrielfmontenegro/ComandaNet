package com.example.demo.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class NotaFiscal {

    private Long id;
    private Long clienteId;
    private String nomeCliente;
    private String documentoCliente;
    private List<ItemNota> itens;
    private BigDecimal total;
    private LocalDateTime dataEmissao;

    public NotaFiscal(Long id, Long clienteId, String nomeCliente,
                      String documentoCliente, List<ItemNota> itens,
                      BigDecimal total, LocalDateTime dataEmissao) {
        this.id = id;
        this.clienteId = clienteId;
        this.nomeCliente = nomeCliente;
        this.documentoCliente = documentoCliente;
        this.itens = itens;
        this.total = total;
        this.dataEmissao = dataEmissao;
    }

    public Long getId() {
        return id;
    }

    public Long getClienteId() {
        return clienteId;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public String getDocumentoCliente() {
        return documentoCliente;
    }

    public List<ItemNota> getItens() {
        return itens;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public LocalDateTime getDataEmissao() {
        return dataEmissao;
    }
}