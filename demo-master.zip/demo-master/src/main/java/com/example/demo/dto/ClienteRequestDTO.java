package com.example.demo.dto;

public record ClienteRequestDTO(
        String nome,
        String documento,
        String email,
        String telefone
) {}