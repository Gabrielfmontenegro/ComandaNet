package com.example.demo.controller;

import com.example.demo.dto.NotaFiscalRequestDTO;
import com.example.demo.dto.NotaFiscalResponseDTO;
import com.example.demo.service.NotaFiscalService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notas-fiscais")
public class NotaFiscalController {

    private final NotaFiscalService service;

    public NotaFiscalController(NotaFiscalService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<NotaFiscalResponseDTO> emitir(
            @RequestBody NotaFiscalRequestDTO corpo) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.emitir(corpo));
    }

    @GetMapping
    public ResponseEntity<List<NotaFiscalResponseDTO>> listar() {
        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<NotaFiscalResponseDTO> buscar(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }
}