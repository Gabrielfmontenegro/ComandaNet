package com.example.demo.dto;

import java.util.List;

public record NotaFiscalRequestDTO(
        Long clienteId,
        List<ItemNotaRequestDTO> itens
) {
}