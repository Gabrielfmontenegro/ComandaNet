package com.example.demo.repository;

import com.example.demo.model.NotaFiscal;

import java.util.List;
import java.util.Optional;

public interface NotaFiscalRepository {

    NotaFiscal salvar(NotaFiscal nota);

    List<NotaFiscal> listarTodas();

    Optional<NotaFiscal> buscarPorId(Long id);
}