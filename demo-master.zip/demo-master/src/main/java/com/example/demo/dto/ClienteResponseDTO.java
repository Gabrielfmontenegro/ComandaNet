package com.example.demo.dto;

public record ClienteResponseDTO(
        Long id,
        String nome,
        String documento,
        String email,
        String telefone
) {
}