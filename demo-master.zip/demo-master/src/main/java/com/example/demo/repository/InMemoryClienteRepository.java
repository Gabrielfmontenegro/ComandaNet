package com.example.demo.repository;

import com.example.demo.model.Cliente;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class InMemoryClienteRepository implements ClienteRepository {

    private final Map<Long, Cliente> banco = new LinkedHashMap<>();

    @Override
    public Cliente salvar(Cliente cliente) {
        banco.put(cliente.getId(), cliente);
        return cliente;
    }

    @Override
    public List<Cliente> listarTodos() {
        return new ArrayList<>(banco.values());
    }

    @Override
    public Optional<Cliente> buscarPorId(Long id) {
        return Optional.ofNullable(banco.get(id));
    }

    @Override
    public Cliente atualizar(Cliente cliente) {
        banco.put(cliente.getId(), cliente);
        return cliente;
    }

    @Override
    public Optional<Cliente> deletar(Long id) {
        return Optional.ofNullable(banco.remove(id));
    }
}