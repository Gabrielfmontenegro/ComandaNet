package com.example.demo.service;

import com.example.demo.dto.ItemNotaRequestDTO;
import com.example.demo.dto.ItemNotaResponseDTO;
import com.example.demo.dto.NotaFiscalRequestDTO;
import com.example.demo.dto.NotaFiscalResponseDTO;
import com.example.demo.model.Cliente;
import com.example.demo.model.ItemNota;
import com.example.demo.model.NotaFiscal;
import com.example.demo.model.Produto;
import com.example.demo.repository.ClienteRepository;
import com.example.demo.repository.InMemoryNotaFiscalRepository;
import com.example.demo.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class NotaFiscalService {

    private final InMemoryNotaFiscalRepository notaRepository;
    private final ClienteRepository clienteRepository;
    private final ProdutoRepository produtoRepository;

    private final AtomicLong sequencia = new AtomicLong();

    public NotaFiscalService(
            InMemoryNotaFiscalRepository notaRepository,
            ClienteRepository clienteRepository,
            ProdutoRepository produtoRepository) {
        this.notaRepository = notaRepository;
        this.clienteRepository = clienteRepository;
        this.produtoRepository = produtoRepository;
    }

    public NotaFiscalResponseDTO emitir(NotaFiscalRequestDTO dto) {
        if (dto == null || dto.clienteId() == null) {
            throw new IllegalArgumentException(
                    "O cliente da nota é obrigatório.");
        }

        if (dto.itens() == null || dto.itens().isEmpty()) {
            throw new IllegalArgumentException(
                    "A nota precisa ter pelo menos um produto.");
        }

        Cliente cliente = clienteRepository.buscarPorId(dto.clienteId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Cliente não encontrado: " + dto.clienteId()));

        List<ItemNota> itensNota = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        for (ItemNotaRequestDTO itemDTO : dto.itens()) {
            if (itemDTO == null
                    || itemDTO.produtoId() == null
                    || itemDTO.quantidade() == null
                    || itemDTO.quantidade() <= 0) {
                throw new IllegalArgumentException(
                        "Cada item precisa de um produto válido "
                                + "e uma quantidade maior que zero.");
            }

            Produto produto = produtoRepository
                    .buscarPorId(itemDTO.produtoId())
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Produto não encontrado: "
                                    + itemDTO.produtoId()));

            BigDecimal precoUnitario = produto.getPreco()
                    .setScale(2, RoundingMode.HALF_UP);

            BigDecimal subtotal = precoUnitario.multiply(
                            BigDecimal.valueOf(itemDTO.quantidade()))
                    .setScale(2, RoundingMode.HALF_UP);

            ItemNota item = new ItemNota(
                    produto.getId(),
                    produto.getNome(),
                    itemDTO.quantidade(),
                    precoUnitario,
                    subtotal
            );

            itensNota.add(item);
            total = total.add(subtotal);
        }

        total = total.setScale(2, RoundingMode.HALF_UP);

        NotaFiscal nota = new NotaFiscal(
                sequencia.incrementAndGet(),
                cliente.getId(),
                cliente.getNome(),
                cliente.getDocumento(),
                itensNota,
                total,
                LocalDateTime.now()
        );

        return converter(notaRepository.salvar(nota));
    }

    public List<NotaFiscalResponseDTO> listar() {
        List<NotaFiscalResponseDTO> resposta = new ArrayList<>();

        for (NotaFiscal nota : notaRepository.listarTodas()) {
            resposta.add(converter(nota));
        }

        return resposta;
    }

    public NotaFiscalResponseDTO buscarPorId(Long id) {
        NotaFiscal nota = notaRepository.buscarPorId(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Nota fiscal não encontrada: " + id));

        return converter(nota);
    }

    private NotaFiscalResponseDTO converter(NotaFiscal nota) {
        List<ItemNotaResponseDTO> itensDTO = new ArrayList<>();

        for (ItemNota item : nota.getItens()) {
            itensDTO.add(new ItemNotaResponseDTO(
                    item.getProdutoId(),
                    item.getNomeProduto(),
                    item.getQuantidade(),
                    item.getPrecoUnitario(),
                    item.getSubtotal()
            ));
        }

        return new NotaFiscalResponseDTO(
                nota.getId(),
                nota.getClienteId(),
                nota.getNomeCliente(),
                nota.getDocumentoCliente(),
                itensDTO,
                nota.getTotal(),
                nota.getDataEmissao()
        );
    }
}