package com.example.demo.repository;

import com.example.demo.model.Cliente;

import java.util.List;
import java.util.Optional;

public interface ClienteRepository {

    Cliente salvar(Cliente cliente);

    List<Cliente> listarTodos();

    Optional<Cliente> buscarPorId(Long id);

    Cliente atualizar(Cliente cliente);

    Optional<Cliente> deletar(Long id);
}