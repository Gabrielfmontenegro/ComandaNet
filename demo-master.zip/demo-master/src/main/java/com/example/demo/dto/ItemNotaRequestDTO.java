package com.example.demo.dto;

public record ItemNotaRequestDTO(
        Long produtoId,
        Integer quantidade
) {
}