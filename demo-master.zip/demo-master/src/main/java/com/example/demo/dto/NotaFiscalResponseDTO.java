package com.example.demo.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record NotaFiscalResponseDTO(
        Long id,
        Long clienteId,
        String nomeCliente,
        String documentoCliente,
        List<ItemNotaResponseDTO> itens,
        BigDecimal total,
        LocalDateTime dataEmissao
) {
}