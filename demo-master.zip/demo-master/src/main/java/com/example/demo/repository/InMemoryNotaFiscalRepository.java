package com.example.demo.repository;

import com.example.demo.model.NotaFiscal;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class InMemoryNotaFiscalRepository
        implements NotaFiscalRepository {

    private final Map<Long, NotaFiscal> banco = new LinkedHashMap<>();

    @Override
    public NotaFiscal salvar(NotaFiscal nota) {
        banco.put(nota.getId(), nota);
        return nota;
    }

    @Override
    public List<NotaFiscal> listarTodas() {
        return new ArrayList<>(banco.values());
    }

    @Override
    public Optional<NotaFiscal> buscarPorId(Long id) {
        return Optional.ofNullable(banco.get(id));
    }
}