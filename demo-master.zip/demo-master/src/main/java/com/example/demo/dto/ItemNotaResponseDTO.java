package com.example.demo.dto;

import java.math.BigDecimal;

public record ItemNotaResponseDTO(
        Long produtoId,
        String nomeProduto,
        Integer quantidade,
        BigDecimal precoUnitario,
        BigDecimal subtotal
) {
}