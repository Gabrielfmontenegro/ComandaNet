package com.example.demo.service;

import com.example.demo.dto.ClienteRequestDTO;
import com.example.demo.dto.ClienteResponseDTO;
import com.example.demo.model.Cliente;
import com.example.demo.repository.InMemoryClienteRepository;
import com.example.demo.repository.ClienteRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class ClienteService {

    private final ClienteRepository repository;
    private final AtomicLong sequencia = new AtomicLong();

    public ClienteService(InMemoryClienteRepository repository) {
        this.repository = repository;
    }

    public ClienteResponseDTO criar(ClienteRequestDTO dto) {
        validar(dto);

        boolean documentoExiste = repository.listarTodos().stream()
                .anyMatch(c -> c.getDocumento().equals(dto.documento().trim()));

        if (documentoExiste) {
            throw new IllegalArgumentException(
                    "Já existe um cliente com esse CPF/CNPJ."
            );
        }

        Cliente cliente = new Cliente(
                sequencia.incrementAndGet(),
                dto.nome().trim(),
                dto.documento().trim(),
                dto.email(),
                dto.telefone()
        );

        return converter(repository.salvar(cliente));
    }

    public List<ClienteResponseDTO> listar() {
        List<ClienteResponseDTO> resposta = new ArrayList<>();

        for (Cliente cliente : repository.listarTodos()) {
            resposta.add(converter(cliente));
        }

        return resposta;
    }

    public ClienteResponseDTO buscarPorId(Long id) {
        Cliente cliente = repository.buscarPorId(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Cliente não encontrado: " + id
                ));

        return converter(cliente);
    }

    public ClienteResponseDTO atualizar(
            Long id, ClienteRequestDTO dto) {

        validar(dto);

        Cliente existente = repository.buscarPorId(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Cliente não encontrado: " + id
                ));

        boolean documentoExiste = repository.listarTodos().stream()
                .anyMatch(c ->
                        !c.getId().equals(id)
                                && c.getDocumento().equals(dto.documento().trim())
                );

        if (documentoExiste) {
            throw new IllegalArgumentException(
                    "Outro cliente já utiliza esse CPF/CNPJ."
            );
        }

        existente.setNome(dto.nome().trim());
        existente.setDocumento(dto.documento().trim());
        existente.setEmail(dto.email());
        existente.setTelefone(dto.telefone());

        return converter(repository.atualizar(existente));
    }

    public ClienteResponseDTO deletar(Long id) {
        Cliente removido = repository.deletar(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Cliente não encontrado: " + id
                ));

        return converter(removido);
    }

    private void validar(ClienteRequestDTO dto) {
        if (dto == null) {
            throw new IllegalArgumentException(
                    "Os dados do cliente são obrigatórios."
            );
        }

        if (dto.nome() == null || dto.nome().isBlank()) {
            throw new IllegalArgumentException(
                    "O nome do cliente é obrigatório."
            );
        }

        if (dto.documento() == null || dto.documento().isBlank()) {
            throw new IllegalArgumentException(
                    "O CPF/CNPJ é obrigatório."
            );
        }
    }

    private ClienteResponseDTO converter(Cliente cliente) {
        return new ClienteResponseDTO(
                cliente.getId(),
                cliente.getNome(),
                cliente.getDocumento(),
                cliente.getEmail(),
                cliente.getTelefone()
        );
    }
}