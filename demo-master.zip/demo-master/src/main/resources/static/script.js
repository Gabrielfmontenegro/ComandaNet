/* =========================================
   NF-SYSTEM — SCRIPT PRINCIPAL
   Integração com Java Spring Boot
   ========================================= */
const API = {
    produtos: "/produtos",
    clientes: "/clientes",
    notas: "/notas-fiscais"
};
const $ = (seletor) => document.querySelector(seletor);
const state = {
    produtos: [],
    clientes: [],
    notas: [],
    toastTimer: null
};
/* =========================================
   REQUISIÇÕES À API
   ========================================= */
async function requisicao(url, opcoes = {}) {
    const resposta = await fetch(url, {
        ...opcoes,
        headers: {
            "Content-Type": "application/json",
            ...(opcoes.headers || {})
        }
    });
    if (!resposta.ok) {
        let mensagem = `Erro HTTP ${resposta.status}`;
        try {
            const erro = await resposta.json();
            mensagem = erro.message || erro.mensagem || mensagem;
        } catch {
            // Mantém a mensagem HTTP se a resposta não for JSON.
        }
        throw new Error(mensagem);
    }
    if (resposta.status === 204) {
        return null;
    }
    const texto = await resposta.text();
    return texto ? JSON.parse(texto) : null;
}
/* =========================================
   SEGURANÇA E FORMATAÇÃO
   ========================================= */
function escapar(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, caractere => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[caractere]);
}
function moeda(valor) {
    return Number(valor || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}
function dataFormatada(valor) {
    if (!valor) return "—";
    const data = new Date(valor);
    if (Number.isNaN(data.getTime())) {
        return escapar(valor);
    }
    return data.toLocaleString("pt-BR");
}
function mostrarToast(mensagem, tipo = "success") {
    const toast = $("#toast");
    if (!toast) return;
    clearTimeout(state.toastTimer);
    toast.textContent = mensagem;
    toast.className = `toast ${tipo}`;
    toast.hidden = false;
    state.toastTimer = setTimeout(() => {
        toast.hidden = true;
    }, 4000);
}
function mostrarMensagem(seletor, mensagem, tipo = "success") {
    const elemento = $(seletor);
    if (!elemento) return;
    elemento.textContent = mensagem;
    elemento.className = `form-message ${tipo}`;
}
/* =========================================
   NAVEGAÇÃO ENTRE AS PÁGINAS
   ========================================= */
function navegar(pagina) {
    const paginasValidas = ["inicio", "produtos", "clientes", "notas"];
    if (!paginasValidas.includes(pagina)) return;
    document.querySelectorAll(".page").forEach(secao => {
        secao.hidden = secao.id !== pagina;
    });
    document.querySelectorAll(".nav-item").forEach(botao => {
        const ativo = botao.dataset.page === pagina;
        botao.classList.toggle("active", ativo);
        if (ativo) {
            botao.setAttribute("aria-current", "page");
        } else {
            botao.removeAttribute("aria-current");
        }
    });
    const titulos = {
        inicio: "Dashboard",
        produtos: "Produtos",
        clientes: "Clientes",
        notas: "Notas fiscais"
    };
    const titulo = $("#page-title");
    if (titulo) {
        titulo.textContent = titulos[pagina];
    }
    if (pagina === "produtos") carregarProdutos();
    if (pagina === "clientes") carregarClientes();
    if (pagina === "notas") carregarNotas();
}
function configurarNavegacao() {
    document.querySelectorAll("[data-page]").forEach(botao => {
        botao.addEventListener("click", () => {
            navegar(botao.dataset.page);
        });
    });
}
/* =========================================
   DASHBOARD
   ========================================= */
async function atualizarDashboard() {
    const botao = $("#refresh-dashboard");
    if (botao) botao.disabled = true;
    try {
        const [produtos, clientes, notas] = await Promise.all([
            requisicao(API.produtos),
            requisicao(API.clientes),
            requisicao(API.notas)
        ]);
        state.produtos = Array.isArray(produtos) ? produtos : [];
        state.clientes = Array.isArray(clientes) ? clientes : [];
        state.notas = Array.isArray(notas) ? notas : [];
        $("#total-produtos").textContent = state.produtos.length;
        $("#total-clientes").textContent = state.clientes.length;
        $("#total-notas").textContent = state.notas.length;
    } catch (erro) {
        mostrarToast(
            `Não foi possível atualizar o dashboard: ${erro.message}`,
            "error"
        );
    } finally {
        if (botao) botao.disabled = false;
    }
}
/* =========================================
   PRODUTOS
   ========================================= */
async function carregarProdutos() {
    const tabela = $("#tabela-produtos");
    try {
        const dados = await requisicao(API.produtos);
        state.produtos = Array.isArray(dados) ? dados : [];
        if (tabela) {
            if (state.produtos.length === 0) {
                tabela.innerHTML = `
                    <tr>
                        <td colspan="5" class="empty">
                            Nenhum produto cadastrado.
                        </td>
                    </tr>
                `;
            } else {
                tabela.innerHTML = state.produtos.map(produto => `
                    <tr>
                        <td>${escapar(produto.id)}</td>
                        <td>${escapar(produto.nome)}</td>
                        <td>${moeda(produto.preco)}</td>
                        <td>${escapar(produto.estoque)}</td>
                        <td>${escapar(produto.descricao || "—")}</td>
                    </tr>
                `).join("");
            }
        }
        const contador = $("#contador-produtos");
        if (contador) contador.textContent = state.produtos.length;
        preencherProdutosNota();
        atualizarContadorDashboard("total-produtos", state.produtos.length);
    } catch (erro) {
        if (tabela) {
            tabela.innerHTML = `
                <tr>
                    <td colspan="5" class="empty">
                        Não foi possível carregar os produtos.
                    </td>
                </tr>
            `;
        }
        mostrarToast(`Erro ao carregar produtos: ${erro.message}`, "error");
    }
}
async function cadastrarProduto(evento) {
    evento.preventDefault();
    const formulario = evento.currentTarget;
    const botao = formulario.querySelector('button[type="submit"]');
    const dados = new FormData(formulario);
    const produto = {
        nome: String(dados.get("nome") || "").trim(),
        descricao: String(dados.get("descricao") || "").trim(),
        preco: Number(dados.get("preco")),
        estoque: Number(dados.get("estoque"))
    };
    if (!produto.nome) {
        mostrarMensagem("#mensagem-produto", "Informe o nome do produto.", "error");
        return;
    }
    if (!Number.isFinite(produto.preco) || produto.preco < 0) {
        mostrarMensagem("#mensagem-produto", "Informe um preço válido.", "error");
        return;
    }
    if (!Number.isInteger(produto.estoque) || produto.estoque < 0) {
        mostrarMensagem("#mensagem-produto", "Informe um estoque válido.", "error");
        return;
    }
    botao.disabled = true;
    try {
        await requisicao(API.produtos, {
            method: "POST",
            body: JSON.stringify(produto)
        });
        formulario.reset();
        mostrarMensagem(
            "#mensagem-produto",
            "Produto cadastrado com sucesso!",
            "success"
        );
        mostrarToast("Produto cadastrado com sucesso!");
        await carregarProdutos();
        await atualizarDashboard();
    } catch (erro) {
        mostrarMensagem(
            "#mensagem-produto",
            `Não foi possível cadastrar: ${erro.message}`,
            "error"
        );
    } finally {
        botao.disabled = false;
    }
}
/* =========================================
   CLIENTES
   ========================================= */
async function carregarClientes() {
    const tabela = $("#tabela-clientes");
    try {
        const dados = await requisicao(API.clientes);
        state.clientes = Array.isArray(dados) ? dados : [];
        if (tabela) {
            if (state.clientes.length === 0) {
                tabela.innerHTML = `
                    <tr>
                        <td colspan="5" class="empty">
                            Nenhum cliente cadastrado.
                        </td>
                    </tr>
                `;
            } else {
                tabela.innerHTML = state.clientes.map(cliente => `
                    <tr>
                        <td>${escapar(cliente.id)}</td>
                        <td>${escapar(cliente.nome)}</td>
                        <td>${escapar(cliente.documento)}</td>
                        <td>${escapar(cliente.email)}</td>
                        <td>${escapar(cliente.telefone || "—")}</td>
                    </tr>
                `).join("");
            }
        }
        const contador = $("#contador-clientes");
        if (contador) contador.textContent = state.clientes.length;
        preencherClientesNota();
        atualizarContadorDashboard("total-clientes", state.clientes.length);
    } catch (erro) {
        if (tabela) {
            tabela.innerHTML = `
                <tr>
                    <td colspan="5" class="empty">
                        Não foi possível carregar os clientes.
                    </td>
                </tr>
            `;
        }
        mostrarToast(`Erro ao carregar clientes: ${erro.message}`, "error");
    }
}
async function cadastrarCliente(evento) {
    evento.preventDefault();
    const formulario = evento.currentTarget;
    const botao = formulario.querySelector('button[type="submit"]');
    const dados = new FormData(formulario);
    const cliente = {
        nome: String(dados.get("nome") || "").trim(),
        documento: String(dados.get("documento") || "").trim(),
        email: String(dados.get("email") || "").trim(),
        telefone: String(dados.get("telefone") || "").trim()
    };
    if (!cliente.nome || !cliente.documento || !cliente.email) {
        mostrarMensagem(
            "#mensagem-cliente",
            "Preencha nome, documento e e-mail.",
            "error"
        );
        return;
    }
    botao.disabled = true;
    try {
        await requisicao(API.clientes, {
            method: "POST",
            body: JSON.stringify(cliente)
        });
        formulario.reset();
        mostrarMensagem(
            "#mensagem-cliente",
            "Cliente cadastrado com sucesso!",
            "success"
        );
        mostrarToast("Cliente cadastrado com sucesso!");
        await carregarClientes();
        await atualizarDashboard();
    } catch (erro) {
        mostrarMensagem(
            "#mensagem-cliente",
            `Não foi possível cadastrar: ${erro.message}`,
            "error"
        );
    } finally {
        botao.disabled = false;
    }
}
/* =========================================
   NOTAS FISCAIS
   ========================================= */
function preencherClientesNota() {
    const campo = document.querySelector('[name="clienteId"]');
    if (!campo) return;
    const selecionado = campo.value;
    campo.innerHTML = `
        <option value="">Selecione um cliente</option>
        ${state.clientes.map(cliente => `
            <option value="${escapar(cliente.id)}">
                ${escapar(cliente.nome)} — ${escapar(cliente.documento)}
            </option>
        `).join("")}
    `;
    if (state.clientes.some(cliente => String(cliente.id) === selecionado)) {
        campo.value = selecionado;
    }
}
function preencherProdutosNota() {
    const campo = document.querySelector('[name="produtoId"]');
    if (!campo) return;
    const selecionado = campo.value;
    campo.innerHTML = `
        <option value="">Selecione um produto</option>
        ${state.produtos.map(produto => `
            <option value="${escapar(produto.id)}">
                ${escapar(produto.nome)} — ${moeda(produto.preco)}
                (estoque: ${escapar(produto.estoque)})
            </option>
        `).join("")}
    `;
    if (state.produtos.some(produto => String(produto.id) === selecionado)) {
        campo.value = selecionado;
    }
}
async function carregarNotas() {
    const tabela = $("#tabela-notas");
    try {
        const dados = await requisicao(API.notas);
        state.notas = Array.isArray(dados) ? dados : [];
        if (tabela) {
            if (state.notas.length === 0) {
                tabela.innerHTML = `
                    <tr>
                        <td colspan="5" class="empty">
                            Nenhuma nota fiscal emitida.
                        </td>
                    </tr>
                `;
            } else {
                tabela.innerHTML = state.notas.map(nota => `
                    <tr>
                        <td>${escapar(nota.id)}</td>
                        <td>${escapar(nota.nomeCliente || nota.clienteId || "—")}</td>
                        <td>${moeda(nota.total)}</td>
                        <td>${dataFormatada(nota.dataEmissao)}</td>
                        <td>
                            <button
                                class="table-action"
                                type="button"
                                data-nota-id="${escapar(nota.id)}"
                            >
                                Ver detalhes
                            </button>
                        </td>
                    </tr>
                `).join("");
            }
        }
        const contador = $("#contador-notas");
        if (contador) contador.textContent = state.notas.length;
        atualizarContadorDashboard("total-notas", state.notas.length);
    } catch (erro) {
        if (tabela) {
            tabela.innerHTML = `
                <tr>
                    <td colspan="5" class="empty">
                        Não foi possível carregar as notas fiscais.
                    </td>
                </tr>
            `;
        }
        mostrarToast(`Erro ao carregar notas: ${erro.message}`, "error");
    }
}
async function emitirNota(evento) {
    evento.preventDefault();
    const formulario = evento.currentTarget;
    const botao = formulario.querySelector('button[type="submit"]');
    const dados = new FormData(formulario);
    const clienteId = Number(dados.get("clienteId"));
    const produtoId = Number(dados.get("produtoId"));
    const quantidade = Number(dados.get("quantidade"));
    if (!clienteId || !produtoId || !Number.isInteger(quantidade) || quantidade < 1) {
        mostrarMensagem(
            "#mensagem-nota",
            "Selecione um cliente, um produto e uma quantidade válida.",
            "error"
        );
        return;
    }
    botao.disabled = true;
    try {
        const nota = await requisicao(API.notas, {
            method: "POST",
            body: JSON.stringify({
                clienteId,
                itens: [
                    {
                        produtoId,
                        quantidade
                    }
                ]
            })
        });
        mostrarMensagem(
            "#mensagem-nota",
            `Nota fiscal emitida com sucesso! Número: ${nota?.id ?? "—"}`,
            "success"
        );
        mostrarToast("Nota fiscal emitida com sucesso!");
        formulario.reset();
        await Promise.all([
            carregarNotas(),
            carregarProdutos(),
            atualizarDashboard()
        ]);
        if (nota?.id != null) {
            await verDetalhesNota(nota.id);
        }
    } catch (erro) {
        mostrarMensagem(
            "#mensagem-nota",
            `Não foi possível emitir a nota: ${erro.message}`,
            "error"
        );
    } finally {
        botao.disabled = false;
    }
}
async function verDetalhesNota(id) {
    try {
        const nota = await requisicao(`${API.notas}/${encodeURIComponent(id)}`);
        const painel = $("#detalhes-nota");
        const titulo = $("#detalhes-titulo");
        const conteudo = $("#detalhes-conteudo");
        if (!painel || !conteudo) return;
        if (titulo) {
            titulo.textContent = `Nota fiscal #${nota.id}`;
        }
        const itens = Array.isArray(nota.itens) ? nota.itens : [];
        conteudo.innerHTML = `
            <div class="details-grid">
                <div class="detail-box">
                    <small>Número da nota</small>
                    <strong>${escapar(nota.id)}</strong>
                </div>
                <div class="detail-box">
                    <small>Cliente</small>
                    <strong>${escapar(nota.nomeCliente || "—")}</strong>
                </div>
                <div class="detail-box">
                    <small>Documento</small>
                    <strong>${escapar(nota.documentoCliente || "—")}</strong>
                </div>
                <div class="detail-box">
                    <small>Data de emissão</small>
                    <strong>${dataFormatada(nota.dataEmissao)}</strong>
                </div>
                <div class="detail-box">
                    <small>Total da nota</small>
                    <strong>${moeda(nota.total)}</strong>
                </div>
            </div>
            <div class="section-heading">
                <h2>Itens da nota</h2>
            </div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Produto</th>
                            <th>Quantidade</th>
                            <th>Preço unitário</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${
            itens.length
                ? itens.map(item => `
                                    <tr>
                                        <td>${escapar(item.nomeProduto || item.produtoId || "—")}</td>
                                        <td>${escapar(item.quantidade ?? "—")}</td>
                                        <td>${moeda(item.precoUnitario)}</td>
                                        <td>${moeda(item.subtotal)}</td>
                                    </tr>
                                `).join("")
                : `
                                    <tr>
                                        <td colspan="4" class="empty">
                                            Nenhum item encontrado.
                                        </td>
                                    </tr>
                                `
        }
                    </tbody>
                </table>
            </div>
        `;
        painel.hidden = false;
        painel.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (erro) {
        mostrarToast(`Não foi possível consultar a nota: ${erro.message}`, "error");
    }
}
/* =========================================
   ATUALIZAÇÃO DE CONTADORES
   ========================================= */
function atualizarContadorDashboard(id, quantidade) {
    const elemento = document.getElementById(id);
    if (elemento) {
        elemento.textContent = quantidade;
    }
}
/* =========================================
   EVENTOS
   ========================================= */
function configurarEventos() {
    $("#form-produto")?.addEventListener("submit", cadastrarProduto);
    $("#form-cliente")?.addEventListener("submit", cadastrarCliente);
    $("#form-nota")?.addEventListener("submit", emitirNota);
    $("#refresh-dashboard")?.addEventListener("click", atualizarDashboard);
    $("#refresh-products")?.addEventListener("click", carregarProdutos);
    $("#refresh-clients")?.addEventListener("click", carregarClientes);
    $("#refresh-notas")?.addEventListener("click", carregarNotas);
    $("#close-details")?.addEventListener("click", () => {
        const painel = $("#detalhes-nota");
        if (painel) {
            painel.hidden = true;
        }
    });
    $("#tabela-notas")?.addEventListener("click", evento => {
        const botao = evento.target.closest("[data-nota-id]");
        if (botao) {
            verDetalhesNota(botao.dataset.notaId);
        }
    });
}
/* =========================================
   INICIALIZAÇÃO
   ========================================= */
document.addEventListener("DOMContentLoaded", () => {
    configurarNavegacao();
    configurarEventos();
    navegar("inicio");
    // Carrega os dados iniciais para o dashboard.
    atualizarDashboard();
});