package com.example.demo.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record NotaFiscalResponseDTO(
        Long id,
        List<ItemNotaResponseDTO> itens,
        BigDecimal total,
        LocalDateTime dataEmissao
) {}