
package com.example.demo.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class NotaFiscal {

    private Long id;
    private List<ItemNota> itens;
    private BigDecimal total;
    private LocalDateTime dataEmissao;

    public NotaFiscal(
            Long id,
            List<ItemNota> itens,
            BigDecimal total,
            LocalDateTime dataEmissao
    ) {
        this.id = id;
        this.itens = itens;
        this.total = total;
        this.dataEmissao = dataEmissao;
    }

    public Long getId() {
        return id;
    }

    public List<ItemNota> getItens() {
        return itens;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public LocalDateTime getDataEmissao() {
        return dataEmissao;
    }
}
