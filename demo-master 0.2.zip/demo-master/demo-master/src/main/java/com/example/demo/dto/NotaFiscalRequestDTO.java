package com.example.demo.dto;

import java.util.List;

public record NotaFiscalRequestDTO(
        List<ItemNotaRequestDTO> itens
) {}