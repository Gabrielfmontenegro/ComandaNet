
package com.example.demo.service;

import com.example.demo.dto.ItemNotaRequestDTO;
import com.example.demo.dto.ItemNotaResponseDTO;
import com.example.demo.dto.NotaFiscalRequestDTO;
import com.example.demo.dto.NotaFiscalResponseDTO;
import com.example.demo.model.ItemNota;
import com.example.demo.model.NotaFiscal;
import com.example.demo.model.Produto;
import com.example.demo.repository.InMemoryNotaFiscalRepository;
import com.example.demo.repository.ProdutoRepository;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class NotaFiscalService {

    private final InMemoryNotaFiscalRepository notaRepository;
    private final ProdutoRepository produtoRepository;
    private final AtomicLong sequencia = new AtomicLong();

    public NotaFiscalService(
            InMemoryNotaFiscalRepository notaRepository,
            ProdutoRepository produtoRepository
    ) {
        this.notaRepository = notaRepository;
        this.produtoRepository = produtoRepository;
    }

    public synchronized NotaFiscalResponseDTO emitir(
            NotaFiscalRequestDTO dto
    ) {
        if (dto == null
                || dto.itens() == null
                || dto.itens().isEmpty()) {
            throw new IllegalArgumentException(
                    "A nota precisa ter pelo menos um produto."
            );
        }

        Map<Long, Produto> produtos = new LinkedHashMap<>();
        Map<Long, Integer> quantidades = new LinkedHashMap<>();
        List<ItemNota> itensNota = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        // FASE 1: validar todos os itens sem alterar o estoque.
        for (ItemNotaRequestDTO itemDTO : dto.itens()) {
            if (itemDTO == null
                    || itemDTO.produtoId() == null
                    || itemDTO.quantidade() == null
                    || itemDTO.quantidade() <= 0) {
                throw new IllegalArgumentException(
                        "Cada item precisa de um produto válido "
                                + "e uma quantidade maior que zero."
                );
            }

            Long produtoId = itemDTO.produtoId();

            Produto produto = produtos.get(produtoId);

            if (produto == null) {
                produto = produtoRepository.buscarPorId(produtoId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Produto não encontrado: "
                                                + produtoId
                                )
                        );

                produtos.put(produtoId, produto);
            }

            int quantidadeAnterior =
                    quantidades.getOrDefault(produtoId, 0);

            int quantidadeNova;

            try {
                quantidadeNova = Math.addExact(
                        quantidadeAnterior,
                        itemDTO.quantidade()
                );
            } catch (ArithmeticException erro) {
                throw new IllegalArgumentException(
                        "Quantidade total inválida para o produto: "
                                + produto.getNome()
                );
            }

            quantidades.put(produtoId, quantidadeNova);

            BigDecimal precoUnitario = produto.getPreco()
                    .setScale(2, RoundingMode.HALF_UP);

            BigDecimal subtotal = precoUnitario
                    .multiply(BigDecimal.valueOf(itemDTO.quantidade()))
                    .setScale(2, RoundingMode.HALF_UP);

            itensNota.add(new ItemNota(
                    produto.getId(),
                    produto.getNome(),
                    itemDTO.quantidade(),
                    precoUnitario,
                    subtotal
            ));

            total = total.add(subtotal);
        }

        // FASE 2: verificar o estoque total necessário de cada produto.
        for (Map.Entry<Long, Integer> entrada
                : quantidades.entrySet()) {

            Produto produto = produtos.get(entrada.getKey());
            int quantidadeNecessaria = entrada.getValue();

            if (produto.getEstoque() == null
                    || produto.getEstoque() < quantidadeNecessaria) {
                throw new IllegalArgumentException(
                        "Estoque insuficiente para o produto '"
                                + produto.getNome()
                                + "'. Disponível: "
                                + produto.getEstoque()
                                + "; solicitado: "
                                + quantidadeNecessaria
                                + ". Nenhum estoque foi alterado."
                );
            }
        }

        // FASE 3: somente após todas as validações, baixar o estoque.
        for (Map.Entry<Long, Integer> entrada
                : quantidades.entrySet()) {

            Produto produto = produtos.get(entrada.getKey());

            produto.setEstoque(
                    produto.getEstoque() - entrada.getValue()
            );

            produtoRepository.atualizar(produto);
        }

        // FASE 4: salvar a nota com os itens e o total calculado.
        total = total.setScale(2, RoundingMode.HALF_UP);

        NotaFiscal nota = new NotaFiscal(
                sequencia.incrementAndGet(),
                itensNota,
                total,
                LocalDateTime.now()
        );

        return converter(notaRepository.salvar(nota));
    }

    public List<NotaFiscalResponseDTO> listar() {
        List<NotaFiscalResponseDTO> respostas = new ArrayList<>();

        for (NotaFiscal nota : notaRepository.listarTodas()) {
            respostas.add(converter(nota));
        }

        return respostas;
    }

    public NotaFiscalResponseDTO buscarPorId(Long id) {
        NotaFiscal nota = notaRepository.buscarPorId(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Nota fiscal não encontrada: " + id
                        )
                );

        return converter(nota);
    }

    private NotaFiscalResponseDTO converter(NotaFiscal nota) {
        List<ItemNotaResponseDTO> itensDTO = new ArrayList<>();

        for (ItemNota item : nota.getItens()) {
            itensDTO.add(new ItemNotaResponseDTO(
                    item.getProdutoId(),
                    item.getNomeProduto(),
                    item.getQuantidade(),
                    item.getPrecoUnitario(),
                    item.getSubtotal()
            ));
        }

        return new NotaFiscalResponseDTO(
                nota.getId(),
                itensDTO,
                nota.getTotal(),
                nota.getDataEmissao()
        );
    }
}
