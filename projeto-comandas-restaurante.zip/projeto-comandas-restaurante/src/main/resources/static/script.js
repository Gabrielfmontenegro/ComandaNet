
/* =========================================
   NF-SYSTEM — SCRIPT PRINCIPAL
   Integração com Java Spring Boot
   ========================================= */

const API = {
    produtos: "/produtos",
    comandas: "/comandas"
};

const $ = (seletor) => document.querySelector(seletor);

const state = {
    produtos: [],
    comandas: [],
    itensComanda: [],
    toastTimer: null
};

/* =========================================
   REQUISIÇÕES À API
   ========================================= */

async function requisicao(url, opcoes = {}) {
    const resposta = await fetch(url, {
        ...opcoes,
        headers: {
            "Content-Type": "application/json",
            ...(opcoes.headers || {})
        }
    });

    if (!resposta.ok) {
        let mensagem = `Erro HTTP ${resposta.status}`;

        try {
            const erro = await resposta.json();
            mensagem = erro.message
                || erro.mensagem
                || erro.detail
                || mensagem;
        } catch {
            // Mantém a mensagem HTTP original.
        }

        throw new Error(mensagem);
    }

    if (resposta.status === 204) {
        return null;
    }

    const texto = await resposta.text();
    return texto ? JSON.parse(texto) : null;
}

/* =========================================
   FORMATAÇÃO E MENSAGENS
   ========================================= */

function escapar(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, caractere => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[caractere]);
}

function moeda(valor) {
    return Number(valor || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

function dataFormatada(valor) {
    if (!valor) return "—";

    const data = new Date(valor);

    if (Number.isNaN(data.getTime())) {
        return escapar(valor);
    }

    return data.toLocaleString("pt-BR");
}

function mostrarToast(mensagem, tipo = "success") {
    const toast = $("#toast");
    if (!toast) return;

    clearTimeout(state.toastTimer);

    toast.textContent = mensagem;
    toast.className = `toast ${tipo}`;
    toast.hidden = false;

    state.toastTimer = setTimeout(() => {
        toast.hidden = true;
    }, 4000);
}

function mostrarMensagem(seletor, mensagem, tipo = "success") {
    const elemento = $(seletor);
    if (!elemento) return;

    elemento.textContent = mensagem;
    elemento.className = `form-message ${tipo}`;
}

function atualizarContadorDashboard(id, quantidade) {
    const elemento = document.getElementById(id);

    if (elemento) {
        elemento.textContent = quantidade;
    }
}

/* =========================================
   NAVEGAÇÃO
   ========================================= */

function navegar(pagina) {
    const paginasValidas = ["inicio", "produtos", "comandas"];

    if (!paginasValidas.includes(pagina)) return;

    document.querySelectorAll(".page").forEach(secao => {
        secao.hidden = secao.id !== pagina;
    });

    document.querySelectorAll(".nav-link").forEach(botao => {
        const ativo = botao.dataset.page === pagina;

        botao.classList.toggle("active", ativo);

        if (ativo) {
            botao.setAttribute("aria-current", "page");
        } else {
            botao.removeAttribute("aria-current");
        }
    });

    const titulos = {
        inicio: "Dashboard",
        produtos: "Produtos",
        comandas: "Comandas"
    };

    const subtitulos = {
        inicio: "Acompanhe os dados do seu sistema.",
        produtos: "Cadastre produtos e controle o estoque.",
        comandas: "Emita e consulte comandas."
    };

    if ($("#page-title")) {
        $("#page-title").textContent = titulos[pagina];
    }

    if ($("#page-subtitle")) {
        $("#page-subtitle").textContent = subtitulos[pagina];
    }

    if (pagina === "inicio") {
        atualizarDashboard();
    }

    if (pagina === "produtos") {
        carregarProdutos();
    }

    if (pagina === "comandas") {
        carregarProdutos();
        carregarComandas();
    }

    const sidebar = $("#sidebar");
    if (sidebar) {
        sidebar.classList.remove("open");
    }
}

function configurarNavegacao() {
    document.querySelectorAll("[data-page]").forEach(botao => {
        botao.addEventListener("click", () => {
            navegar(botao.dataset.page);
        });
    });

    $("#mobile-menu")?.addEventListener("click", () => {
        $("#sidebar")?.classList.toggle("open");
    });
}

/* =========================================
   DASHBOARD
   ========================================= */

async function atualizarDashboard() {
    const botao = $("#refresh-dashboard");

    if (botao) botao.disabled = true;

    try {
        const [produtos, comandas] = await Promise.all([
            requisicao(API.produtos),
            requisicao(API.comandas)
        ]);

        state.produtos = Array.isArray(produtos) ? produtos : [];
        state.comandas = Array.isArray(comandas) ? comandas : [];

        atualizarContadorDashboard(
            "total-produtos",
            state.produtos.length
        );

        atualizarContadorDashboard(
            "total-comandas",
            state.comandas.length
        );

        atualizarContadores();
        preencherProdutosComanda();
        renderizarItensComanda();
    } catch (erro) {
        mostrarToast(
            `Não foi possível atualizar o dashboard: ${erro.message}`,
            "error"
        );
    } finally {
        if (botao) botao.disabled = false;
    }
}

/* =========================================
   PRODUTOS
   ========================================= */

async function carregarProdutos() {
    const tabela = $("#tabela-produtos");

    try {
        const dados = await requisicao(API.produtos);

        state.produtos = Array.isArray(dados) ? dados : [];

        if (tabela) {
            if (state.produtos.length === 0) {
                tabela.innerHTML = `
                    <tr>
                        <td colspan="5" class="empty-cell">
                            Nenhum produto cadastrado.
                        </td>
                    </tr>
                `;
            } else {
                tabela.innerHTML = state.produtos.map(produto => `
                    <tr>
                        <td>${escapar(produto.id)}</td>
                        <td>${escapar(produto.nome)}</td>
                        <td>${moeda(produto.preco)}</td>
                        <td>${escapar(produto.estoque)}</td>
                        <td>${escapar(produto.descricao || "—")}</td>
                    </tr>
                `).join("");
            }
        }

        atualizarContadores();
        preencherProdutosComanda();
        renderizarItensComanda();
    } catch (erro) {
        if (tabela) {
            tabela.innerHTML = `
                <tr>
                    <td colspan="5" class="empty-cell">
                        Não foi possível carregar os produtos.
                    </td>
                </tr>
            `;
        }

        mostrarToast(
            `Erro ao carregar produtos: ${erro.message}`,
            "error"
        );
    }
}

async function cadastrarProduto(evento) {
    evento.preventDefault();

    const formulario = evento.currentTarget;
    const botao = formulario.querySelector('button[type="submit"]');
    const dados = new FormData(formulario);

    const produto = {
        nome: String(dados.get("nome") || "").trim(),
        descricao: String(dados.get("descricao") || "").trim(),
        preco: Number(dados.get("preco")),
        estoque: Number(dados.get("estoque"))
    };

    if (!produto.nome) {
        mostrarMensagem(
            "#mensagem-produto",
            "Informe o nome do produto.",
            "error"
        );
        return;
    }

    if (!Number.isFinite(produto.preco) || produto.preco <= 0) {
        mostrarMensagem(
            "#mensagem-produto",
            "O preço deve ser maior que zero.",
            "error"
        );
        return;
    }

    if (!Number.isInteger(produto.estoque) || produto.estoque < 0) {
        mostrarMensagem(
            "#mensagem-produto",
            "O estoque deve ser um número inteiro igual ou maior que zero.",
            "error"
        );
        return;
    }

    botao.disabled = true;

    try {
        await requisicao(API.produtos, {
            method: "POST",
            body: JSON.stringify(produto)
        });

        formulario.reset();

        mostrarMensagem(
            "#mensagem-produto",
            "Produto cadastrado com sucesso!",
            "success"
        );

        mostrarToast("Produto cadastrado com sucesso!");

        await carregarProdutos();
        await atualizarDashboard();
    } catch (erro) {
        mostrarMensagem(
            "#mensagem-produto",
            `Não foi possível cadastrar: ${erro.message}`,
            "error"
        );
    } finally {
        botao.disabled = false;
    }
}

function atualizarContadores() {
    const contadorProdutos = $("#contador-produtos");
    const contadorComandas = $("#contador-comandas");

    if (contadorProdutos) {
        contadorProdutos.textContent =
            `${state.produtos.length} produto(s)`;
    }

    if (contadorComandas) {
        contadorComandas.textContent =
            `${state.comandas.length} comanda(s)`;
    }

    atualizarContadorDashboard(
        "total-produtos",
        state.produtos.length
    );

    atualizarContadorDashboard(
        "total-comandas",
        state.comandas.length
    );
}

/* =========================================
   PRODUTOS DISPONÍVEIS PARA A COMANDA
   ========================================= */

function preencherProdutosComanda() {
    const campo = $("#comanda-produto");
    if (!campo) return;

    const selecionado = campo.value;

    campo.innerHTML = `
        <option value="">Selecione um produto</option>
        ${state.produtos.map(produto => `
            <option value="${escapar(produto.id)}"
                    ${Number(produto.estoque) <= 0 ? "disabled" : ""}>
                ${escapar(produto.nome)} — ${moeda(produto.preco)}
                (estoque: ${escapar(produto.estoque)})
            </option>
        `).join("")}
    `;

    if (
        state.produtos.some(
            produto => String(produto.id) === selecionado
        )
    ) {
        campo.value = selecionado;
    }
}

/* =========================================
   ITENS DA COMANDA
   ========================================= */

function obterProduto(produtoId) {
    return state.produtos.find(
        produto => Number(produto.id) === Number(produtoId)
    );
}

function quantidadeNoRascunho(produtoId) {
    return state.itensComanda
        .filter(item => Number(item.produtoId) === Number(produtoId))
        .reduce((soma, item) => soma + item.quantidade, 0);
}

function adicionarItemComanda() {
    const produtoId = Number($("#comanda-produto")?.value);
    const quantidade = Number($("#comanda-quantidade")?.value);

    if (!produtoId) {
        mostrarMensagem(
            "#mensagem-comanda",
            "Selecione um produto.",
            "error"
        );
        return;
    }

    if (!Number.isInteger(quantidade) || quantidade < 1) {
        mostrarMensagem(
            "#mensagem-comanda",
            "A quantidade deve ser um número inteiro maior que zero.",
            "error"
        );
        return;
    }

    const produto = obterProduto(produtoId);

    if (!produto) {
        mostrarMensagem(
            "#mensagem-comanda",
            "O produto selecionado não foi encontrado. Atualize a lista.",
            "error"
        );
        return;
    }

    const quantidadeAtual = quantidadeNoRascunho(produtoId);
    const quantidadeTotal = quantidadeAtual + quantidade;
    const estoque = Number(produto.estoque);

    if (quantidadeTotal > estoque) {
        mostrarMensagem(
            "#mensagem-comanda",
            `Estoque insuficiente para ${produto.nome}. ` +
            `Disponível: ${Math.max(0, estoque - quantidadeAtual)}.`,
            "error"
        );
        return;
    }

    const existente = state.itensComanda.find(
        item => Number(item.produtoId) === produtoId
    );

    if (existente) {
        existente.quantidade += quantidade;
    } else {
        state.itensComanda.push({
            produtoId: produto.id,
            quantidade
        });
    }

    renderizarItensComanda();

    $("#comanda-quantidade").value = "1";
    $("#comanda-produto").value = "";

    mostrarMensagem(
        "#mensagem-comanda",
        "Produto adicionado à comanda.",
        "success"
    );
}

function removerItemComanda(produtoId) {
    state.itensComanda = state.itensComanda.filter(
        item => Number(item.produtoId) !== Number(produtoId)
    );

    renderizarItensComanda();

    mostrarMensagem(
        "#mensagem-comanda",
        "Produto removido da comanda.",
        "success"
    );
}

function renderizarItensComanda() {
    const tabela = $("#itens-comanda");
    const totalElemento = $("#total-previsto");

    if (!tabela) return;

    if (state.itensComanda.length === 0) {
        tabela.innerHTML = `
            <tr>
                <td colspan="5" class="empty-cell">
                    Nenhum produto adicionado.
                </td>
            </tr>
        `;

        if (totalElemento) {
            totalElemento.textContent = moeda(0);
        }

        return;
    }

    let total = 0;

    tabela.innerHTML = state.itensComanda.map(item => {
        const produto = obterProduto(item.produtoId);

        if (!produto) {
            return `
                <tr>
                    <td colspan="5" class="empty-cell">
                        Produto ${escapar(item.produtoId)} não encontrado.
                        Remova-o e adicione novamente.
                    </td>
                </tr>
            `;
        }

        const preco = Number(produto.preco);
        const subtotal = preco * item.quantidade;

        total += subtotal;

        return `
            <tr>
                <td>${escapar(produto.nome)}</td>
                <td>${escapar(item.quantidade)}</td>
                <td>${moeda(preco)}</td>
                <td>${moeda(subtotal)}</td>
                <td>
                    <button
                        class="table-action"
                        type="button"
                        data-remover-produto="${escapar(item.produtoId)}">
                        Remover
                    </button>
                </td>
            </tr>
        `;
    }).join("");

    if (totalElemento) {
        totalElemento.textContent = moeda(total);
    }
}

/* =========================================
   EMISSÃO DE COMANDA
   ========================================= */

async function emitirComanda(evento) {
    evento.preventDefault();

    const formulario = evento.currentTarget;
    const botao = formulario.querySelector('button[type="submit"]');

    if (state.itensComanda.length === 0) {
        mostrarMensagem(
            "#mensagem-comanda",
            "Adicione pelo menos um produto antes de emitir a comanda.",
            "error"
        );
        return;
    }

    // Confere novamente o estoque antes de enviar a solicitação.
    for (const item of state.itensComanda) {
        const produto = obterProduto(item.produtoId);

        if (!produto) {
            mostrarMensagem(
                "#mensagem-comanda",
                `O produto ${item.produtoId} não está disponível. Atualize os produtos.`,
                "error"
            );
            return;
        }

        if (item.quantidade > Number(produto.estoque)) {
            mostrarMensagem(
                "#mensagem-comanda",
                `Estoque insuficiente para ${produto.nome}. Atualize os produtos e confira a quantidade.`,
                "error"
            );

            await carregarProdutos();
            return;
        }
    }

    // O backend espera uma lista de itens; não é necessário clienteId.
    const corpo = {
        itens: state.itensComanda.map(item => ({
            produtoId: Number(item.produtoId),
            quantidade: Number(item.quantidade)
        }))
    };

    botao.disabled = true;

    try {
        const comanda = await requisicao(API.comandas, {
            method: "POST",
            body: JSON.stringify(corpo)
        });

        state.itensComanda = [];
        renderizarItensComanda();

        formulario.reset();
        $("#comanda-quantidade").value = "1";

        mostrarMensagem(
            "#mensagem-comanda",
            `Comanda emitida com sucesso! Número: ${comanda?.id ?? "—"}`,
            "success"
        );

        mostrarToast("Comanda emitida com sucesso!");

        await Promise.all([
            carregarProdutos(),
            carregarComandas(),
            atualizarDashboard()
        ]);

        if (comanda?.id != null) {
            await verDetalhesComanda(comanda.id);
        }
    } catch (erro) {
        mostrarMensagem(
            "#mensagem-comanda",
            `Não foi possível emitir a comanda: ${erro.message}`,
            "error"
        );

        mostrarToast(
            `Erro ao emitir comanda: ${erro.message}`,
            "error"
        );

        // Atualiza os dados, pois o estoque pode ter mudado.
        await carregarProdutos();
    } finally {
        botao.disabled = false;
    }
}

/* =========================================
   LISTA DE COMANDAS
   ========================================= */

async function carregarComandas() {
    const tabela = $("#tabela-comandas");

    try {
        const dados = await requisicao(API.comandas);
        state.comandas = Array.isArray(dados) ? dados : [];

        if (tabela) {
            if (state.comandas.length === 0) {
                tabela.innerHTML = `
                    <tr>
                        <td colspan="5" class="empty-cell">
                            Nenhuma comanda emitida.
                        </td>
                    </tr>
                `;
            } else {
                tabela.innerHTML = state.comandas.map(comanda => {
                    const itens = Array.isArray(comanda.itens)
                        ? comanda.itens
                        : [];

                    const quantidadeItens = itens.reduce(
                        (soma, item) => soma + Number(item.quantidade || 0),
                        0
                    );

                    return `
                        <tr>
                            <td>${escapar(comanda.id)}</td>
                            <td>${dataFormatada(comanda.dataEmissao)}</td>
                            <td>${quantidadeItens}</td>
                            <td>${moeda(comanda.total)}</td>
                            <td>
                                <button
                                    class="table-action"
                                    type="button"
                                    data-comanda-id="${escapar(comanda.id)}">
                                    Ver detalhes
                                </button>
                            </td>
                        </tr>
                    `;
                }).join("");
            }
        }

        atualizarContadores();
    } catch (erro) {
        if (tabela) {
            tabela.innerHTML = `
                <tr>
                    <td colspan="5" class="empty-cell">
                        Não foi possível carregar as comandas.
                    </td>
                </tr>
            `;
        }

        mostrarToast(
            `Erro ao carregar comandas: ${erro.message}`,
            "error"
        );
    }
}

/* =========================================
   DETALHES DA COMANDA
   ========================================= */

async function verDetalhesComanda(id) {
    try {
        const comanda = await requisicao(
            `${API.comandas}/${encodeURIComponent(id)}`
        );

        const painel = $("#detalhes-comanda");
        const titulo = $("#detalhes-titulo");
        const conteudo = $("#detalhes-conteudo");

        if (!painel || !conteudo) return;

        if (titulo) {
            titulo.textContent = `Comanda #${comanda.id}`;
        }

        const itens = Array.isArray(comanda.itens) ? comanda.itens : [];

        conteudo.innerHTML = `
            <div class="details-grid">
                <div class="detail-box">
                    <small>Número da comanda</small>
                    <strong>${escapar(comanda.id)}</strong>
                </div>

                <div class="detail-box">
                    <small>Data de emissão</small>
                    <strong>${dataFormatada(comanda.dataEmissao)}</strong>
                </div>

                <div class="detail-box">
                    <small>Quantidade de itens</small>
                    <strong>${itens.reduce(
                        (soma, item) => soma + Number(item.quantidade || 0),
                        0
                    )}</strong>
                </div>

                <div class="detail-box">
                    <small>Total da comanda</small>
                    <strong>${moeda(comanda.total)}</strong>
                </div>
            </div>

            <div class="section-heading">
                <h2>Itens da comanda</h2>
            </div>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Produto</th>
                            <th>Quantidade</th>
                            <th>Preço unitário</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>

                    <tbody>
                        ${
                            itens.length
                                ? itens.map(item => `
                                    <tr>
                                        <td>${escapar(
                                            item.nomeProduto || item.produtoId || "—"
                                        )}</td>
                                        <td>${escapar(item.quantidade ?? "—")}</td>
                                        <td>${moeda(item.precoUnitario)}</td>
                                        <td>${moeda(item.subtotal)}</td>
                                    </tr>
                                `).join("")
                                : `
                                    <tr>
                                        <td colspan="4" class="empty-cell">
                                            Nenhum item encontrado.
                                        </td>
                                    </tr>
                                `
                        }
                    </tbody>
                </table>
            </div>
        `;

        painel.hidden = false;
        painel.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    } catch (erro) {
        mostrarToast(
            `Não foi possível consultar a comanda: ${erro.message}`,
            "error"
        );
    }
}

/* =========================================
   EVENTOS
   ========================================= */

function configurarEventos() {
    $("#form-produto")?.addEventListener(
        "submit",
        cadastrarProduto
    );

    $("#form-comanda")?.addEventListener(
        "submit",
        emitirComanda
    );

    $("#adicionar-item")?.addEventListener(
        "click",
        adicionarItemComanda
    );

    $("#itens-comanda")?.addEventListener("click", evento => {
        const botao = evento.target.closest("[data-remover-produto]");

        if (botao) {
            removerItemComanda(botao.dataset.removerProduto);
        }
    });

    $("#refresh-dashboard")?.addEventListener(
        "click",
        atualizarDashboard
    );

    $("#refresh-products")?.addEventListener(
        "click",
        carregarProdutos
    );

    $("#refresh-comandas")?.addEventListener(
        "click",
        carregarComandas
    );

    $("#close-details")?.addEventListener("click", () => {
        const painel = $("#detalhes-comanda");

        if (painel) {
            painel.hidden = true;
        }
    });

    $("#tabela-comandas")?.addEventListener("click", evento => {
        const botao = evento.target.closest("[data-comanda-id]");

        if (botao) {
            verDetalhesComanda(botao.dataset.comandaId);
        }
    });
}

/* =========================================
   INICIALIZAÇÃO
   ========================================= */

document.addEventListener("DOMContentLoaded", () => {
    configurarNavegacao();
    configurarEventos();
    renderizarItensComanda();
    navegar("inicio");
});
