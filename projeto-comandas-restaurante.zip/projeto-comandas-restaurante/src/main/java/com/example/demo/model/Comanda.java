
package com.example.demo.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class Comanda {

    private Long id;
    private List<ItemComanda> itens;
    private BigDecimal total;
    private LocalDateTime dataEmissao;

    public Comanda(
            Long id,
            List<ItemComanda> itens,
            BigDecimal total,
            LocalDateTime dataEmissao
    ) {
        this.id = id;
        this.itens = itens;
        this.total = total;
        this.dataEmissao = dataEmissao;
    }

    public Long getId() {
        return id;
    }

    public List<ItemComanda> getItens() {
        return itens;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public LocalDateTime getDataEmissao() {
        return dataEmissao;
    }
}
