
package com.example.demo.service;

import com.example.demo.dto.ItemComandaRequestDTO;
import com.example.demo.dto.ItemComandaResponseDTO;
import com.example.demo.dto.ComandaRequestDTO;
import com.example.demo.dto.ComandaResponseDTO;
import com.example.demo.model.ItemComanda;
import com.example.demo.model.Comanda;
import com.example.demo.model.Produto;
import com.example.demo.repository.InMemoryComandaRepository;
import com.example.demo.repository.ProdutoRepository;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class ComandaService {

    private final InMemoryComandaRepository comandaRepository;
    private final ProdutoRepository produtoRepository;
    private final AtomicLong sequencia = new AtomicLong();

    public ComandaService(
            InMemoryComandaRepository comandaRepository,
            ProdutoRepository produtoRepository
    ) {
        this.comandaRepository = comandaRepository;
        this.produtoRepository = produtoRepository;
    }

    public synchronized ComandaResponseDTO emitir(
            ComandaRequestDTO dto
    ) {
        if (dto == null
                || dto.itens() == null
                || dto.itens().isEmpty()) {
            throw new IllegalArgumentException(
                    "A comanda precisa ter pelo menos um produto."
            );
        }

        Map<Long, Produto> produtos = new LinkedHashMap<>();
        Map<Long, Integer> quantidades = new LinkedHashMap<>();
        List<ItemComanda> itensComanda = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        // FASE 1: validar todos os itens sem alterar o estoque.
        for (ItemComandaRequestDTO itemDTO : dto.itens()) {
            if (itemDTO == null
                    || itemDTO.produtoId() == null
                    || itemDTO.quantidade() == null
                    || itemDTO.quantidade() <= 0) {
                throw new IllegalArgumentException(
                        "Cada item precisa de um produto válido "
                                + "e uma quantidade maior que zero."
                );
            }

            Long produtoId = itemDTO.produtoId();

            Produto produto = produtos.get(produtoId);

            if (produto == null) {
                produto = produtoRepository.buscarPorId(produtoId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Produto não encontrado: "
                                                + produtoId
                                )
                        );

                produtos.put(produtoId, produto);
            }

            int quantidadeAnterior =
                    quantidades.getOrDefault(produtoId, 0);

            int quantidadeNova;

            try {
                quantidadeNova = Math.addExact(
                        quantidadeAnterior,
                        itemDTO.quantidade()
                );
            } catch (ArithmeticException erro) {
                throw new IllegalArgumentException(
                        "Quantidade total inválida para o produto: "
                                + produto.getNome()
                );
            }

            quantidades.put(produtoId, quantidadeNova);

            BigDecimal precoUnitario = produto.getPreco()
                    .setScale(2, RoundingMode.HALF_UP);

            BigDecimal subtotal = precoUnitario
                    .multiply(BigDecimal.valueOf(itemDTO.quantidade()))
                    .setScale(2, RoundingMode.HALF_UP);

            itensComanda.add(new ItemComanda(
                    produto.getId(),
                    produto.getNome(),
                    itemDTO.quantidade(),
                    precoUnitario,
                    subtotal
            ));

            total = total.add(subtotal);
        }

        // FASE 2: verificar o estoque total necessário de cada produto.
        for (Map.Entry<Long, Integer> entrada
                : quantidades.entrySet()) {

            Produto produto = produtos.get(entrada.getKey());
            int quantidadeNecessaria = entrada.getValue();

            if (produto.getEstoque() == null
                    || produto.getEstoque() < quantidadeNecessaria) {
                throw new IllegalArgumentException(
                        "Estoque insuficiente para o produto '"
                                + produto.getNome()
                                + "'. Disponível: "
                                + produto.getEstoque()
                                + "; solicitado: "
                                + quantidadeNecessaria
                                + ". Nenhum estoque foi alterado."
                );
            }
        }

        // FASE 3: somente após todas as validações, baixar o estoque.
        for (Map.Entry<Long, Integer> entrada
                : quantidades.entrySet()) {

            Produto produto = produtos.get(entrada.getKey());

            produto.setEstoque(
                    produto.getEstoque() - entrada.getValue()
            );

            produtoRepository.atualizar(produto);
        }

        // FASE 4: salvar a comanda com os itens e o total calculado.
        total = total.setScale(2, RoundingMode.HALF_UP);

        Comanda comanda = new Comanda(
                sequencia.incrementAndGet(),
                itensComanda,
                total,
                LocalDateTime.now()
        );

        return converter(comandaRepository.salvar(comanda));
    }

    public List<ComandaResponseDTO> listar() {
        List<ComandaResponseDTO> respostas = new ArrayList<>();

        for (Comanda comanda : comandaRepository.listarTodas()) {
            respostas.add(converter(comanda));
        }

        return respostas;
    }

    public ComandaResponseDTO buscarPorId(Long id) {
        Comanda comanda = comandaRepository.buscarPorId(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Comanda não encontrada: " + id
                        )
                );

        return converter(comanda);
    }

    private ComandaResponseDTO converter(Comanda comanda) {
        List<ItemComandaResponseDTO> itensDTO = new ArrayList<>();

        for (ItemComanda item : comanda.getItens()) {
            itensDTO.add(new ItemComandaResponseDTO(
                    item.getProdutoId(),
                    item.getNomeProduto(),
                    item.getQuantidade(),
                    item.getPrecoUnitario(),
                    item.getSubtotal()
            ));
        }

        return new ComandaResponseDTO(
                comanda.getId(),
                itensDTO,
                comanda.getTotal(),
                comanda.getDataEmissao()
        );
    }
}
