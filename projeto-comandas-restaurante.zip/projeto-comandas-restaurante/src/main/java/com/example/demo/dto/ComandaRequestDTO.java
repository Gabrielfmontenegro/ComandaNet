package com.example.demo.dto;

import java.util.List;

public record ComandaRequestDTO(
        List<ItemComandaRequestDTO> itens
) {}